﻿Crewniverse Font V.2

Crewniverse is a font that replicates the one used for the title cards of the TV show Steven Universe(tm), as well as the logo of the Steven Crewniverse's Tumblr.

2015 - Font by MaxiGamer - maxigamer.deviantart.com
Made in FontForge.

Steven Universe(tm) was created by Rebecca Sugar and is a trademark of Cartoon Network.

-------------------------------------------------------------------------------------------

Changelog for V.2
- Added exclamation and question marks;
- Updated every other punctuation.
Goals for V.3 or V.4
- Add quotation marks;
- Add numbers (at least 2 and 3);
- Add accents;
- Add various special characters.

Changelog for V.1:
- Font was created (June 13th, 2015);
- Added letters + some punctuation.
Goals for V.2
- Add exclamation and question marks;
- Add quotation marks;
- Possibly add numbers (at least 2 and 3);
- Possibly add accents on letters A, E, I, O, U and C;
- Might add some other special characters.